"""Generate the original vector figures used by the EvoXRB paper.

The quantitative panels are derived only from the committed case-study
artifacts.  No observational values are synthesized here.
"""

from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch
import numpy as np
import pandas as pd
from PIL import Image, ImageOps


ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "results"
OUT = Path(__file__).resolve().parent / "figures"

BLACK = "#111111"
DARK_GREY = "#333333"
MID_GREY = "#666666"
PALE_GREY = "#eeeeee"
VERY_PALE_GREY = "#f7f7f7"
WHITE = "#ffffff"


def style() -> None:
    plt.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "font.size": 9,
            "axes.titlesize": 10,
            "axes.labelsize": 9,
            "xtick.labelsize": 8,
            "ytick.labelsize": 8,
            "legend.fontsize": 8,
            "axes.spines.top": False,
            "axes.spines.right": False,
            "text.color": BLACK,
            "axes.edgecolor": BLACK,
            "axes.labelcolor": BLACK,
            "xtick.color": BLACK,
            "ytick.color": BLACK,
            "figure.dpi": 160,
            "savefig.dpi": 300,
            "pdf.fonttype": 42,
        }
    )


def box(
    ax,
    xy,
    width,
    height,
    title,
    lines,
    edge=BLACK,
    face=WHITE,
    linestyle="-",
    title_size=8.2,
    text_size=7.4,
):
    patch = FancyBboxPatch(
        xy,
        width,
        height,
        boxstyle="round,pad=0.015,rounding_size=0.02",
        linewidth=1.5,
        edgecolor=edge,
        facecolor=face,
        linestyle=linestyle,
    )
    ax.add_patch(patch)
    x, y = xy
    ax.text(
        x + 0.025,
        y + height - 0.055,
        title,
        color=BLACK,
        weight="bold",
        va="top",
        fontsize=title_size,
        linespacing=1.05,
    )
    title_lines = title.count("\n") + 1
    ax.text(
        x + 0.025,
        y + height - 0.125 - 0.045 * (title_lines - 1),
        "\n".join(lines),
        color=BLACK,
        va="top",
        linespacing=1.3,
        fontsize=text_size,
    )
    return patch


def arrow(ax, start, end, color=BLACK, linestyle="-"):
    ax.add_patch(
        FancyArrowPatch(
            start,
            end,
            arrowstyle="-|>",
            mutation_scale=11,
            linewidth=1.25,
            color=color,
            linestyle=linestyle,
        )
    )


def development_map() -> None:
    fig, ax = plt.subplots(figsize=(7.15, 3.55))
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis("off")

    box(
        ax,
        (0.015, 0.42),
        0.29,
        0.46,
        "v0.1.0 | synthetic\nfoundation",
        [
            "Forward-folded count",
            "simulator",
            "Poisson C-statistic objective",
            "Genetic search + local polish",
            "Deterministic seeded outputs",
        ],
        BLACK,
        VERY_PALE_GREY,
        text_size=6.8,
    )
    box(
        ax,
        (0.355, 0.42),
        0.29,
        0.46,
        "v0.2.0 | observable\nworkflow",
        [
            "Posterior and timing products",
            "Recovery and",
            "misspecification tests",
            "Provenance, replay, acceptance",
            "Context-only MAXI reference",
        ],
        BLACK,
        WHITE,
        text_size=6.8,
    )
    box(
        ax,
        (0.695, 0.42),
        0.29,
        0.46,
        "proposed v0.3.0 |\nphysical study",
        [
            "OGIP HXMT/NICER",
            "likelihoods",
            "Pinned XSPEC physical grid",
            "Joint spectral-timing",
            "posteriors",
            "Blinded hypothesis calibration",
        ],
        BLACK,
        PALE_GREY,
        "--",
        text_size=6.8,
    )
    arrow(ax, (0.305, 0.65), (0.355, 0.65))
    arrow(ax, (0.645, 0.65), (0.695, 0.65), BLACK, "--")

    ax.annotate(
        "validated software evidence",
        xy=(0.327, 0.28),
        ha="center",
        color=BLACK,
        weight="bold",
    )
    ax.plot([0.04, 0.625], [0.33, 0.33], color=BLACK, lw=1.2)
    ax.plot([0.04, 0.04], [0.30, 0.33], color=BLACK, lw=1.2)
    ax.plot([0.625, 0.625], [0.30, 0.33], color=BLACK, lw=1.2)

    ax.plot([0.67, 0.67], [0.38, 0.91], color=BLACK, lw=1.2, ls=(0, (4, 3)))
    box(
        ax,
        (0.70, 0.06),
        0.28,
        0.25,
        "External acceptance required",
        ["pinned grid + immutable data", "200 x 24 calibration", "observational analysis"],
        BLACK,
        WHITE,
        title_size=7.2,
        text_size=6.6,
    )
    ax.set_title("EvoXRB methodological progression and the claim boundary", pad=5, weight="bold")
    fig.tight_layout()
    fig.savefig(OUT / "development-map.pdf", bbox_inches="tight")
    fig.savefig(OUT / "development-map.png", bbox_inches="tight")
    plt.close(fig)


def results_diagnostics() -> None:
    optim = pd.read_csv(RESULTS / "recovery_optimizers.csv")
    summary = pd.read_csv(RESULTS / "recovery_summary.csv")
    posterior = pd.read_csv(RESULTS / "posterior_summary.csv")
    timing = pd.read_csv(RESULTS / "timing_results.csv")
    truth = pd.read_csv(RESULTS / "truth.csv").set_index("epoch_id")

    fig, axes = plt.subplots(2, 2, figsize=(7.15, 6.45))
    ax = axes[0, 0]
    methods = [("ga", "raw", "GA, raw", DARK_GREY, "s"), ("ga+scipy", "polished", "GA + L-BFGS-B", BLACK, "o")]
    rng = np.random.default_rng(1820070)
    for xpos, (method, stage, label, color, marker) in enumerate(methods):
        values = optim.loc[(optim.method == method) & (optim.stage == stage), "delta_c"].to_numpy(float)
        values = np.clip(values, 1e-10, None)
        jitter = rng.uniform(-0.07, 0.07, len(values))
        ax.scatter(np.full(len(values), xpos) + jitter, values, s=32, marker=marker, facecolor=color, edgecolor=WHITE, linewidth=0.5, label=label)
        ax.plot([xpos - 0.14, xpos + 0.14], [np.median(values), np.median(values)], color="#222222", lw=2)
    ax.axhline(1.0, color=MID_GREY, lw=1, ls="--")
    ax.text(1.08, 1.3, r"$\Delta C=1$", color=MID_GREY, fontsize=8)
    ax.set_yscale("log")
    ax.set_xticks([0, 1], ["GA, raw", "GA + local polish"])
    ax.set_ylabel(r"$\Delta C$ from multi-start optimum")
    ax.set_title("(a) Hybrid optimization\ncloses the search gap", loc="left", weight="bold", fontsize=8.5)
    ax.grid(axis="y", alpha=0.2)

    ax = axes[0, 1]
    params = ["tin", "ndisk", "gamma", "norm"]
    display = [r"$T_{\rm in}$", r"$N_{\rm disk}$", r"$\Gamma$", r"$K$"]
    truth_values = {"tin": 0.70, "ndisk": 8000.0, "gamma": 2.10, "norm": 0.25}
    x = np.arange(len(params))
    width = 0.34
    for offset, scenario, label, color, hatch in [
        (-width / 2, "correct_model", "correct model", PALE_GREY, ""),
        (width / 2, "cutoff_truth_powerlaw_fit", "misspecified fit", MID_GREY, "///"),
    ]:
        vals = []
        for p in params:
            row = summary[(summary.scenario == scenario) & (summary.method == "ga+scipy") & (summary.parameter == p)].iloc[0]
            vals.append(100.0 * float(row.rmse) / truth_values[p])
        ax.bar(x + offset, vals, width=width, label=label, color=color, edgecolor=BLACK, linewidth=0.7, hatch=hatch)
    ax.set_xticks(x, display)
    ax.set_ylabel("RMSE / injected value (%)")
    ax.set_title("(b) Misspecification bias\nsurvives optimization", loc="left", weight="bold", fontsize=8.5)
    ax.legend(frameon=False)
    ax.grid(axis="y", alpha=0.2)

    ax = axes[1, 0]
    t = truth.loc["E08"]
    labels = [r"$T_{\rm in}$", r"$N_{\rm disk}$", r"$\Gamma$", r"$K$"]
    y = np.arange(4)
    centers, lower, upper = [], [], []
    for _, row in posterior.set_index("parameter").loc[params].iterrows():
        tv = float(t[row.name])
        half = 0.5 * (float(row.q84) - float(row.q16))
        centers.append((float(row["median"]) - tv) / half)
        lower.append((float(row["median"]) - float(row.q16)) / half)
        upper.append((float(row.q84) - float(row["median"])) / half)
    ax.errorbar(centers, y, xerr=np.array([lower, upper]), fmt="o", color=BLACK, ecolor=BLACK, capsize=3, ms=5)
    ax.axvline(0, color=MID_GREY, lw=1, ls="--")
    ax.set_yticks(y, labels)
    ax.invert_yaxis()
    ax.set_xlabel("displacement from truth (half-interval units)")
    ax.set_title("(c) E08 posterior recovery", loc="left", weight="bold", fontsize=8.5)
    ax.grid(axis="x", alpha=0.2)

    ax = axes[1, 1]
    x = np.arange(len(timing))
    injected = timing["injected_qpo_hz"].to_numpy(float)
    recovered = timing["centroid_hz"].to_numpy(float)
    errors = timing["centroid_error_hz"].to_numpy(float)
    detected = timing["detected"].to_numpy(bool)
    for i in range(len(timing)):
        if np.isfinite(injected[i]):
            ax.scatter(i, injected[i], marker="x", s=52, color=MID_GREY, linewidth=1.6, zorder=3)
        if np.isfinite(recovered[i]):
            marker = "o" if detected[i] else "s"
            ax.errorbar(i, recovered[i], yerr=errors[i], fmt=marker, ms=5, color=BLACK, markerfacecolor=BLACK if detected[i] else WHITE, capsize=3, zorder=4)
    ax.set_yscale("log")
    ax.set_xticks(x, timing.epoch_id)
    ax.set_ylabel("QPO centroid frequency (Hz)")
    ax.set_title("(d) QPO recovery and non-detections", loc="left", weight="bold", fontsize=8.5)
    ax.set_xlim(-0.3, 2.3)
    ax.set_ylim(0.015, 20.0)
    ax.text(0.08, 0.018, "not detected\n(Q < 2)", color=BLACK, ha="left", va="bottom", fontsize=7.5)
    ax.text(1, 9.0, "detected", color=BLACK, ha="center", va="bottom", fontsize=8)
    ax.text(2, 0.08, "no QPO injected\nnone recovered", color=MID_GREY, ha="center", va="center", fontsize=8)
    ax.scatter([], [], marker="x", color=MID_GREY, label="injected")
    ax.scatter([], [], marker="o", color=BLACK, label="recovered, detected")
    ax.scatter([], [], marker="s", facecolor=WHITE, edgecolor=BLACK, label="recovered, not detected")
    ax.legend(frameon=False, loc="upper left")
    ax.grid(axis="y", alpha=0.2)

    fig.suptitle("Validated synthetic evidence from the canonical smoke bundle", weight="bold", y=1.01)
    fig.tight_layout(rect=[0, 0, 1, 0.965], h_pad=3.0, w_pad=3.0)
    fig.savefig(OUT / "results-diagnostics.pdf", bbox_inches="tight")
    fig.savefig(OUT / "results-diagnostics.png", bbox_inches="tight")
    plt.close(fig)


def protocol_map() -> None:
    fig, ax = plt.subplots(figsize=(7.15, 4.0))
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis("off")
    nodes = [
        ((0.025, 0.61), 0.215, 0.25, "Immutable inputs", ["HXMT primary", "NICER sensitivity", "MAXI cross-check"], VERY_PALE_GREY),
        ((0.27, 0.61), 0.215, 0.25, "Epoch inference", ["OGIP likelihoods", "physical spectra", "Whittle timing"], WHITE),
        ((0.515, 0.61), 0.215, 0.25, "Posterior recycling", ["shared distance", "QPO/noise mixture", "phase offsets"], PALE_GREY),
        ((0.76, 0.61), 0.215, 0.25, "Four hypotheses", [r"$H_0, H_\Gamma, H_\tau$", r"$H_{\Gamma+\tau}$", "standardized slopes"], WHITE),
    ]
    for xy, w, h, title, lines, face in nodes:
        box(ax, xy, w, h, title, lines, BLACK, face, title_size=6.8, text_size=6.8)
    arrow(ax, (0.24, 0.735), (0.27, 0.735))
    arrow(ax, (0.485, 0.735), (0.515, 0.735))
    arrow(ax, (0.73, 0.735), (0.76, 0.735))

    box(ax, (0.11, 0.18), 0.27, 0.24, "Blinded calibration", ["3 x 6 smoke", "200 x 24 full", r"$H_0/H_\Gamma/H_\tau$"], BLACK, VERY_PALE_GREY, title_size=7.2)
    box(ax, (0.405, 0.18), 0.29, 0.24, "Predictive comparison", ["PSIS-LOO ELPD", "exact refit if k > 0.7", "contiguous block CV"], BLACK, WHITE, title_size=7.2)
    box(ax, (0.72, 0.18), 0.26, 0.24, "Decision", ["> 2 SE preference", "prior/model sensitivity", "association only"], BLACK, PALE_GREY, title_size=7.2)
    arrow(ax, (0.865, 0.61), (0.55, 0.42))
    arrow(ax, (0.38, 0.30), (0.405, 0.30))
    arrow(ax, (0.695, 0.30), (0.72, 0.30))
    ax.text(0.50, 0.05, "Unblinding and observational reporting are permitted only after all non-waivable gates pass.", ha="center", color=BLACK, weight="bold")
    ax.set_title("Preregistered v0.3 disk-corona/QPO association workflow", weight="bold", pad=5)
    fig.tight_layout()
    fig.savefig(OUT / "protocol-map.pdf", bbox_inches="tight")
    fig.savefig(OUT / "protocol-map.png", bbox_inches="tight")
    plt.close(fig)


def grayscale_source_figures() -> None:
    """Create print-safe monochrome copies of the two raster source figures."""

    sources = {
        ROOT / "figures" / "generated" / "response_area.png": OUT / "response-area-bw.png",
        ROOT / "figures" / "generated" / "folded_spectrum.png": OUT / "folded-spectrum-bw.png",
    }
    for source, destination in sources.items():
        with Image.open(source) as image:
            grayscale = ImageOps.grayscale(image.convert("RGB"))
            grayscale.save(destination, dpi=(300, 300), optimize=True)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    style()
    development_map()
    results_diagnostics()
    protocol_map()
    grayscale_source_figures()


if __name__ == "__main__":
    main()
