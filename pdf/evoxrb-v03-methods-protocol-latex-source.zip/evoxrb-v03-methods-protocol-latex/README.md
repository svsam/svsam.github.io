# EvoXRB scientific paper

The publication manuscript is written in LaTeX:

- `evoxrb-v03-methods-protocol.tex` -- main article
- `evoxrb-references.bib` -- primary-source bibliography
- `make_paper_figures.py` -- reproducible vector figures derived from accepted results
- `figures/` -- generated PDF and PNG figure assets

The compiled paper is available at
[`../output/pdf/evoxrb-v03-methods-protocol.pdf`](../output/pdf/evoxrb-v03-methods-protocol.pdf).

The paper deliberately distinguishes the released package (v0.2.0) from the
proposed third methodological generation. It reports synthetic validation and
a registered v0.3 protocol; it does not claim a completed observational result.

## Build

From the repository root:

```powershell
python paper/make_paper_figures.py
New-Item -ItemType Directory -Force tmp\pdfs | Out-Null
Set-Location paper
pdflatex --interaction=nonstopmode --halt-on-error --output-directory=../tmp/pdfs evoxrb-v03-methods-protocol.tex
bibtex ../tmp/pdfs/evoxrb-v03-methods-protocol
pdflatex --interaction=nonstopmode --halt-on-error --output-directory=../tmp/pdfs evoxrb-v03-methods-protocol.tex
pdflatex --interaction=nonstopmode --halt-on-error --output-directory=../tmp/pdfs evoxrb-v03-methods-protocol.tex
```

Copy the resulting PDF from `tmp/pdfs/` to `output/pdf/` after inspecting the
rendered pages and confirming that the repository tests pass.
